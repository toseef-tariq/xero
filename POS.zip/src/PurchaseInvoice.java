
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmad
 */
public class PurchaseInvoice extends javax.swing.JFrame {
    int pono=0;
    
    
    private void deleteOrder() {
        try {
            
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            
            st.executeUpdate("delete from POSAdmin.PURCHASETABLE where PONO = "+pono+" ");
            
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
    }
    
    private void selectINo () {
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            
            ResultSet rs=st.executeQuery("select * from PURCHASEINVOICE");

            int two=0;
            while(rs.next()) {
                int one=Integer.parseInt(rs.getString(2));
                if(one>two)
                {
                    two=one;    
                }
            }
            
            String text=Integer.toString(two);
            String Code = String.valueOf(Integer.parseInt(text) + 1);
            invoiceno.setText(Code);
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
    }
    private void selecetPONO () {
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            
            ResultSet rs=st.executeQuery("select * from PURCHASETABLE");

            int two=0;
            while(rs.next()) {
                int one=Integer.parseInt(rs.getString(1));
                if(one>two)
                {
                    PoNo.addItem(rs.getString(1));    
                }
                two=one;
            }            
            PoNo.setSelectedIndex(-1);
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    private void loadInfo() {
         try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            String iPoNo=null;
            try {
                iPoNo= PoNo.getSelectedItem().toString();
            } catch(Exception e) {
                JOptionPane.showMessageDialog(null, "Please Select a PONO", "ERROR!", JOptionPane.WARNING_MESSAGE);
                new PurchaseInvoice().setVisible(true);
                dispose();
            }
            
            
            pono=Integer.parseInt(iPoNo);
            ResultSet rs=st.executeQuery("select * from POSAdmin.PURCHASETABLE where PONO = "+pono+" ");
            String a="0";
            while(rs.next()) {
                a=rs.getString(3);
            }
            accName.setText(a);
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
    }
    private void loadStock() {
        try {
            DefaultTableModel model = (DefaultTableModel) invoiceTable.getModel();
            model.setRowCount(0);
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            
            ResultSet rs=st.executeQuery("select *from POSAdmin.PURCHASETABLE where PONO = "+pono+" ");
            
            while(rs.next()) {
                model.addRow(new Object[] { rs.getString(4), rs.getString(5),rs.getString(7),rs.getString(8) , rs.getString(9),rs.getString(10),rs.getString(12),rs.getString(11),rs.getString(13),rs.getString(14)});
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
    }
    
    private void makeOrder() {
        DefaultTableModel model = (DefaultTableModel) invoiceTable.getModel();
        int count=model.getRowCount();
        int code=0;
        int n=0;
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            Statement st1=conn.createStatement();
            for(int i=0;i<count;i++) {
            
                String item=invoiceTable.getValueAt(i, 3).toString();
                n=Integer.parseInt(item);
                
            
            if(n>0) {
                
                
                SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
                
                String AccName=accName.getText();
                
                String invoiceNo=invoiceno.getText();
                int InvoiceNo=Integer.parseInt(invoiceNo);
                
                String spinnerValue = formater.format(date.getValue());
                
                String sCode=invoiceTable.getValueAt(i, 0).toString();
                code=Integer.parseInt(sCode);
                
                String productName=invoiceTable.getValueAt(i, 1).toString();
                
                String purchasePrice=invoiceTable.getValueAt(i, 4).toString();
                int PurchasePrice=Integer.parseInt(purchasePrice);
                
                String salePrice=invoiceTable.getValueAt(i, 5).toString();
                int SalePrice=Integer.parseInt(salePrice);
                
                String WholeSprice=invoiceTable.getValueAt(i, 6).toString();
                int WSPrice=Integer.parseInt(WholeSprice);
                
                String margin=invoiceTable.getValueAt(i, 7).toString();
                int Margin=Integer.parseInt(margin);
                
                String discount=invoiceTable.getValueAt(i, 8).toString();
                int Discount=Integer.parseInt(discount);
                
                String stock=invoiceTable.getValueAt(i,2).toString();
                int inStock=Integer.parseInt(stock);
                
                int total=(n*PurchasePrice);
                
                
                st.executeUpdate("INSERT INTO PURCHASEINVOICE " + "VALUES ( '"+AccName+"' , "+InvoiceNo+" , '"+spinnerValue+"' , "+code+", '"+productName+"' ,  "+n+" , "+PurchasePrice+", "+SalePrice+" ,"+WSPrice+" ,"+Margin+"  ,"+Discount+" , "+total+","+inStock+")");
                inStock=inStock+n;
                st1.executeUpdate("UPDATE POSAdmin.PRODUCT SET OPENINGSTOCK = "+inStock+" ,PURCHASEPRICE = "+PurchasePrice+",MARGIN = "+Margin+" ,SALEPRICE = "+SalePrice+",WHOLESALEPRICE = "+WSPrice+",DISCOUNT = "+Discount+" WHERE CODE ="+code+"");
            }
        }
        }catch(SQLException ex) {
                    Logger.getLogger(PurchaseOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
    }

    private void setIcon() {
        setIconImage(new ImageIcon(getClass().getResource("/IconPack/pos.png")).getImage());
    }
    
    public PurchaseInvoice() {
        initComponents();
        setIcon();
        selecetPONO();
        selectINo();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        invoiceno = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        ans = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        jButton5 = new javax.swing.JButton();
        PoNo = new javax.swing.JComboBox<>();
        date = new javax.swing.JSpinner();
        accName = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        invoiceTable = new javax.swing.JTable();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Purchase Invoice");
        setPreferredSize(new java.awt.Dimension(1366, 729));
        setResizable(false);
        setSize(new java.awt.Dimension(1366, 729));

        jLabel1.setBackground(new java.awt.Color(51, 204, 255));
        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Purchase Invoice");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel1.setOpaque(true);

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel2.setText("P.O.No.");

        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel3.setText("Invoice No.");

        invoiceno.setEditable(false);
        invoiceno.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        invoiceno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invoicenoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel4.setText("Invoice Date:");

        jLabel5.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel5.setText("Account Name:");

        jButton3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/print-icon.png"))); // NOI18N
        jButton3.setText("Print");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/File-New-icon.png"))); // NOI18N
        jButton4.setText("New Invoice");
        jButton4.setPreferredSize(new java.awt.Dimension(127, 33));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Save-icon.png"))); // NOI18N
        jButton6.setText("Save Invoice");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        ans.setEditable(false);
        ans.setBackground(new java.awt.Color(255, 255, 204));
        ans.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        ans.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        ans.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ans.setPreferredSize(new java.awt.Dimension(120, 30));
        ans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ansActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 0, 0));
        jLabel29.setText("Total Payable:");

        jButton5.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Barcode-icon (1).png"))); // NOI18N
        jButton5.setText("Print Barcodes");

        PoNo.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        PoNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PoNoActionPerformed(evt);
            }
        });

        date.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        date.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), new java.util.Date(1499275800000L), null, java.util.Calendar.DAY_OF_MONTH));

        accName.setEditable(false);
        accName.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        accName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accNameActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Arrow-Up-icon.png"))); // NOI18N
        jButton1.setText("Load Account");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        invoiceTable.setAutoCreateRowSorter(true);
        invoiceTable.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        invoiceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Code", "Product Name", "In-Stock", "QTY", "Pur. Price", "Sale Price", "Whole S. Price", "Margin (PKR)", "Dicount (PKR)", "Sub-Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true, true, true, true, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        invoiceTable.getTableHeader().setReorderingAllowed(false);
        invoiceTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                invoiceTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(invoiceTable);

        jButton8.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Actions-dialog-ok-apply-icon.png"))); // NOI18N
        jButton8.setText("Calculate");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(48, 48, 48)
                                .addComponent(PoNo, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(invoiceno, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(accName)))
                        .addGap(46, 46, 46)
                        .addComponent(jButton1)
                        .addGap(10, 10, 10)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jButton6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2)
                            .addComponent(jSeparator1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator5, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE)
                            .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator3))
                        .addGap(119, 119, 119)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel29)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ans, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(124, 124, 124))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 113, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(16, 16, 16))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(PoNo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3)
                                .addComponent(invoiceno, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4)
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(accName, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(8, 8, 8)))
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ans, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void invoicenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invoicenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_invoicenoActionPerformed

    private void ansActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ansActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ansActionPerformed

    private void accNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_accNameActionPerformed

    private void PoNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PoNoActionPerformed
        
    }//GEN-LAST:event_PoNoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        loadInfo();
        loadStock();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        new PurchaseInvoice().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        MessageFormat header = new MessageFormat("XERO\nProduct Suppliers Chart");
        MessageFormat footer = new MessageFormat("End");
        
        try {
            invoiceTable.print(JTable.PrintMode.FIT_WIDTH , header, footer);
        } catch(PrinterException e) {
            JOptionPane.showMessageDialog(null, "Cannot Print", "ERROR!", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        makeOrder();
        deleteOrder();
        new PurchaseInvoice().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void invoiceTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_invoiceTableKeyReleased
        
    }//GEN-LAST:event_invoiceTableKeyReleased

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        DefaultTableModel model = (DefaultTableModel) invoiceTable.getModel();
        int count=model.getRowCount();
        int grandTotal=0;
        for(int i=0;i<count;i++){
            String qty=invoiceTable.getValueAt(i, 3).toString();
            int QTY=Integer.parseInt(qty);
            
            String pp=invoiceTable.getValueAt(i, 4).toString();
            int PP=Integer.parseInt(pp);
            
            int subTotal=PP*QTY;
            
            invoiceTable.setValueAt(subTotal, i, 9);
            
            String total=invoiceTable.getValueAt(i, 9).toString();
            int Total=Integer.parseInt(total);
            grandTotal=grandTotal+Total;
        }
        String a=Integer.toString(grandTotal);
        ans.setText(a);
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PurchaseInvoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PurchaseInvoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PurchaseInvoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PurchaseInvoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PurchaseInvoice().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> PoNo;
    private javax.swing.JTextField accName;
    private javax.swing.JTextField ans;
    private javax.swing.JSpinner date;
    private javax.swing.JTable invoiceTable;
    private javax.swing.JTextField invoiceno;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    // End of variables declaration//GEN-END:variables
}
