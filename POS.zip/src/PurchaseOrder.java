
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import java.text.MessageFormat;
import java.awt.print.PrinterException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmad
 */
public class PurchaseOrder extends javax.swing.JFrame {
   
    String Code="0";
    
    
    private void dbConn() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            
            ResultSet rs=st.executeQuery("select * from PURCHASETABLE");
            
            while(rs.next()) {
                Code=rs.getString(1);
            }
            Code = String.valueOf(Integer.parseInt(Code) + 1);
            PoNo.setText(Code);
            
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
        
    }
    }


    private void supplierList () {
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            
            ResultSet rs=st.executeQuery("select * from SUPPLIER");
            
            while(rs.next()) {
                supplier.addItem(rs.getString(2));
            }            
            supplier.setSelectedIndex(-1);
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    private void makeOrder() {
        
        DefaultTableModel model = (DefaultTableModel) purchaseTable.getModel();
        int count=model.getRowCount();
        int n=0;
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            for(int i=0;i<count;i++) {
            for (int j=0;j<10;j++) {
                String item=purchaseTable.getValueAt(i, 4).toString();
                n=Integer.parseInt(item);
                
            }
            if(n>0) {
                int PONo=Integer.parseInt(PoNo.getText());
                SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
                
                String spinnerValue = formater.format(date.getValue());
                
                String iSupplier= supplier.getSelectedItem().toString();
                
                String sCode=purchaseTable.getValueAt(i, 0).toString();
                int code=Integer.parseInt(sCode);
                
                String productName=purchaseTable.getValueAt(i, 1).toString();
                
                String reOrder=purchaseTable.getValueAt(i, 2).toString();
                int ReOrder=Integer.parseInt(reOrder);
                
                String inStock=purchaseTable.getValueAt(i, 3).toString();
                int InStock=Integer.parseInt(inStock);
                
                String qty=purchaseTable.getValueAt(i, 4).toString();
                int QTY=Integer.parseInt(qty);
                
                String purchasePrice=purchaseTable.getValueAt(i, 5).toString();
                int PurchasePrice=Integer.parseInt(purchasePrice);
                
                String salePrice=purchaseTable.getValueAt(i, 6).toString();
                int SalePrice=Integer.parseInt(salePrice);
                
                String margin=purchaseTable.getValueAt(i, 7).toString();
                int Margin=Integer.parseInt(margin);
                
                String WholeSprice=purchaseTable.getValueAt(i, 8).toString();
                int WSPrice=Integer.parseInt(WholeSprice);
                
                String discount=purchaseTable.getValueAt(i, 9).toString();
                int Discount=Integer.parseInt(discount);
                int total=QTY*PurchasePrice;
                st.executeUpdate("INSERT INTO PURCHASETABLE " + "VALUES ( "+PONo+" , '"+spinnerValue+"' , '"+iSupplier+"' , "+code+" , '"+productName+"' , "+ReOrder+" , "+InStock+" , "+QTY+" , "+PurchasePrice+", "+SalePrice+" ,"+Margin+" ,"+WSPrice+" ,"+Discount+" , "+total+")");
                } 
        }
        }catch (NullPointerException | SQLException e) {
            Logger.getLogger(PurchaseOrder.class.getName()).log(Level.SEVERE, null, e);
                
                }   
    }
    
    private void setIcon() {
        setIconImage(new ImageIcon(getClass().getResource("/IconPack/pos.png")).getImage());
    }
    
    public PurchaseOrder() {
        initComponents();
        setIcon();
        supplierList();
        dbConn();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        PoNo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        purchaseTable = new javax.swing.JTable();
        supplier = new javax.swing.JComboBox<>();
        date = new javax.swing.JSpinner();
        ans = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Purchase Order");
        setResizable(false);
        setSize(new java.awt.Dimension(1366, 729));

        jLabel1.setBackground(new java.awt.Color(51, 204, 255));
        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Purchase Order");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel1.setOpaque(true);

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel2.setText("P.O.No.");

        PoNo.setEditable(false);
        PoNo.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel3.setText("Date :");

        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel4.setText("Supplier :");

        jButton1.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Arrow-Up-icon.png"))); // NOI18N
        jButton1.setText("Load Stock");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Actions-dialog-ok-apply-icon.png"))); // NOI18N
        jButton2.setText("Make Order");
        jButton2.setPreferredSize(new java.awt.Dimension(155, 33));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/print-icon.png"))); // NOI18N
        jButton3.setText("Print");
        jButton3.setPreferredSize(new java.awt.Dimension(100, 33));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/File-New-icon.png"))); // NOI18N
        jButton4.setText("New Order");
        jButton4.setPreferredSize(new java.awt.Dimension(145, 33));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jSeparator4.setPreferredSize(new java.awt.Dimension(0, 4));

        purchaseTable.setAutoCreateRowSorter(true);
        purchaseTable.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        purchaseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Code", "Product Name", "Re-Order", "In-Stock", "Order Qty", "Purchase Price", "Sale Price", "Margin", "Whole S. Price", "Discount", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true, true, false, true, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        purchaseTable.getTableHeader().setReorderingAllowed(false);
        purchaseTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                purchaseTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(purchaseTable);
        if (purchaseTable.getColumnModel().getColumnCount() > 0) {
            purchaseTable.getColumnModel().getColumn(0).setPreferredWidth(20);
            purchaseTable.getColumnModel().getColumn(1).setPreferredWidth(60);
            purchaseTable.getColumnModel().getColumn(2).setPreferredWidth(40);
            purchaseTable.getColumnModel().getColumn(3).setPreferredWidth(40);
            purchaseTable.getColumnModel().getColumn(4).setPreferredWidth(40);
            purchaseTable.getColumnModel().getColumn(5).setPreferredWidth(50);
        }

        supplier.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        supplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supplierActionPerformed(evt);
            }
        });

        date.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        date.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), new java.util.Date(1499275800000L), null, java.util.Calendar.DAY_OF_MONTH));

        ans.setEditable(false);
        ans.setBackground(new java.awt.Color(255, 255, 204));
        ans.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        ans.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        ans.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ans.setPreferredSize(new java.awt.Dimension(120, 30));
        ans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ansActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 0, 0));
        jLabel29.setText("Total Payable:");

        jButton8.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconPack/Actions-dialog-ok-apply-icon.png"))); // NOI18N
        jButton8.setText("Calculate");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(10, 10, 10))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator2)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PoNo, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(supplier, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ans, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(PoNo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2)
                                .addComponent(supplier, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(1, 1, 1)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(15, 15, 15)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ans, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );

        date.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            makeOrder();
            new PurchaseOrder().setVisible(true);
            dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void supplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supplierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_supplierActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        MessageFormat header = new MessageFormat("XERO\nProduct Suppliers Chart");
        MessageFormat footer = new MessageFormat("End");
        
        try {
            purchaseTable.print(JTable.PrintMode.FIT_WIDTH , header, footer);
        } catch(PrinterException e) {
            JOptionPane.showMessageDialog(null, "Cannot Print", "ERROR!", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
             
            DefaultTableModel model = (DefaultTableModel) purchaseTable.getModel();
            model.setRowCount(0);

            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/POS", "posadmin", "posadmin");
            Statement st=conn.createStatement();
            String iSupplier=null;
            try {
                iSupplier= supplier.getSelectedItem().toString();
            } catch(Exception e) {
                JOptionPane.showMessageDialog(null, "Please Select a Supplier", "ERROR!", JOptionPane.WARNING_MESSAGE);
                new PurchaseOrder().setVisible(true);
                dispose();
            }
            
       
            ResultSet rs=st.executeQuery("select * from POSAdmin.Product where Supplier = '"+iSupplier+"' ");
            while(rs.next()) {
            model.addRow(new Object[] { rs.getString(1), rs.getString(2), rs.getString(12) , rs.getString(8) ,"0", rs.getString(13),rs.getString(15),rs.getString(14),rs.getString(16),rs.getString(17) });
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        new PurchaseOrder().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void purchaseTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purchaseTableKeyReleased

    }//GEN-LAST:event_purchaseTableKeyReleased

    private void ansActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ansActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ansActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        DefaultTableModel model = (DefaultTableModel) purchaseTable.getModel();
        int count=model.getRowCount();
        int grandTotal=0;
        for(int i=0;i<count;i++){

            String qty=purchaseTable.getValueAt(i, 4).toString();
            int QTY=Integer.parseInt(qty);
            
            String purchasePrice=purchaseTable.getValueAt(i, 5).toString();
            int PurchasePrice=Integer.parseInt(purchasePrice);
            
            String salePrice=purchaseTable.getValueAt(i, 6).toString();
            int SalePrice=Integer.parseInt(salePrice);
            
            
            int Margin=SalePrice-PurchasePrice;
            
            purchaseTable.setValueAt(Margin, i, 7);
            
            int total=QTY*PurchasePrice;
            
            purchaseTable.setValueAt(total, i, 10);

            String total1=purchaseTable.getValueAt(i, 10).toString();
            int Total=Integer.parseInt(total1);
            grandTotal=grandTotal+Total;
        }
        String a=Integer.toString(grandTotal);
        ans.setText(a);
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PurchaseOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PurchaseOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PurchaseOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PurchaseOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PurchaseOrder().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField PoNo;
    private javax.swing.JTextField ans;
    private javax.swing.JSpinner date;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton8;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTable purchaseTable;
    private javax.swing.JComboBox<String> supplier;
    // End of variables declaration//GEN-END:variables
}
